package com.cash_shop.user;

import java.util.Collections;
import java.util.EnumSet;
import java.util.Set;

import com.cash_shop.employee.Employee.Role;
/**
 * Service layer for the access service workflow. It centralizes validation, business rules, and orchestration logic for this module.
 *
 * This class is part of the Cash Shop desktop application.
 * It keeps the data model, business logic, persistence layer, and UI concerns separated
 * so the project remains easier to understand and share with other developers.
 */



public class AccessService {
/**
 * Classe principale du module module dans l'application Cash Shop. Elle regroupe les responsabilit?s de ce composant pour garder le code lisible et plus facile ? maintenir.
 *
 * Cette classe fait partie de l'application de gestion de supermarch?.
 * Elle aide ? s?parer la logique m?tier, l'acc?s aux donn?es et l'interface
 * utilisateur pour garder le projet plus clair et plus facile ? partager.
 */
/**
 * Core class for the module feature. It groups responsibilities for this component so the code stays readable and easier to maintain.
 *
 * This class is part of the Cash Shop desktop application.
 * It keeps the data model, business logic, persistence layer, and UI concerns separated
 * so the project remains easier to understand and share with other developers.
 */


public enum Module {
        DASHBOARD,
        EMPLOYEES,
        USERS,
        CUSTOMERS,
        PRODUCTS,
        STOCK,
        AISLES,
        SALES,
        SALES_HISTORY,
        SUPPLIERS
    }

    public Set<Module> getAllowedModules(Role role) {
        if (role == null) {
            return Collections.emptySet();
        }
        switch (role) {
            case ADMIN:
                return Collections.unmodifiableSet(EnumSet.of(Module.DASHBOARD, Module.EMPLOYEES, Module.USERS,
                        Module.PRODUCTS, Module.STOCK, Module.AISLES, Module.SUPPLIERS, Module.SALES_HISTORY));
            case MANAGER:
                return Collections.unmodifiableSet(EnumSet.of(
                        Module.PRODUCTS, Module.STOCK, Module.SUPPLIERS, Module.AISLES));
            case COUNTER:
                return Collections.unmodifiableSet(EnumSet.of(Module.EMPLOYEES,
                        Module.PRODUCTS, Module.STOCK, Module.SUPPLIERS, Module.SALES_HISTORY));
            case CASHIER:
                return Collections.unmodifiableSet(EnumSet.of(Module.SALES));
            case AISLE_MANAGER:
                return Collections.unmodifiableSet(EnumSet.of(Module.AISLES));
            case SECURITY:
            case CLEANER:
            default:
                return Collections.emptySet();
        }
    }

    public boolean canAccess(Role role, Module module) {
        return getAllowedModules(role).contains(module);
    }
}
