package com.cash_shop.employee;
/**
 * Domain model representing employee in the Cash Shop system. It stores the data used by the application and exposes it through simple accessors.
 *
 * This class is part of the Cash Shop desktop application.
 * It keeps the data model, business logic, persistence layer, and UI concerns separated
 * so the project remains easier to understand and share with other developers.
 */



public class Employee {
    private String matricule;
    private String firstName;
    private String lastName;
    private String email;
    private double salary;
    private Role role;
/**
 * ?num?ration utilis?e pour d?finir les valeurs valides de role dans l'application. Elle permet d'?viter les ?tats incoh?rents dans le code.
 *
 * Cette classe fait partie de l'application de gestion de supermarch?.
 * Elle aide ? s?parer la logique m?tier, l'acc?s aux donn?es et l'interface
 * utilisateur pour garder le projet plus clair et plus facile ? partager.
 */
/**
 * Enumeration that defines valid role values in the application and prevents invalid state transitions.
 *
 * This class is part of the Cash Shop desktop application.
 * It keeps the data model, business logic, persistence layer, and UI concerns separated
 * so the project remains easier to understand and share with other developers.
 */


public enum Role {
        ADMIN,
        MANAGER,
        COUNTER,
        AISLE_MANAGER,
        CASHIER,
        SECURITY,
        CLEANER,
    }

    public Employee(String matricule, String firstName, String lastName, String email, double salary, Role role) {
        this.matricule = matricule;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.salary = salary;
        this.role = role;
    }

    public String getMatricule() {
        return matricule;
    }
    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public double getSalary() {
        return salary;
    }
    public void setSalary(double salary) {
        this.salary = salary;
    }
    public Role getRole() {
        return role;
    }
    public void setRole(Role role) {
        this.role = role;
    }
    @Override 
    public String toString() {
        return "Employee{" +
                "matricule='" + matricule + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", salary=" + salary +
                ", role=" + role +
                '}';
    }
}
