package com.cash_shop.product;
/**
 * Domain model representing product in the Cash Shop system. It stores the data used by the application and exposes it through simple accessors.
 *
 * This class is part of the Cash Shop desktop application.
 * It keeps the data model, business logic, persistence layer, and UI concerns separated
 * so the project remains easier to understand and share with other developers.
 */



public class Product {

    private int reference;
    private String designation;
    private double purchasePrice;
    private double sellingPrice;
    private int stockQuantity;

    /**
     * Creates a product with its reference, label and pricing data.
     */
    public Product(int reference, String designation, double purchasePrice, double sellingPrice, int stockQuantity) {
        this.reference = reference;
        this.designation = designation;
        this.purchasePrice = purchasePrice;
        this.sellingPrice = sellingPrice;
        this.stockQuantity = stockQuantity;
    }

    // The following getters expose the product details for display, validation
    // and calculations in the business logic.
    public int getReference() {
        return reference;
    }

    public String getDesignation() {
        return designation;
    }

    public double getPurchasePrice() {
        return purchasePrice;
    }

    public double getSellingPrice() {
        return sellingPrice;
    }

    public int getStockQuantity() {
        return stockQuantity;
    }

    /**
     * Simple lookup helper kept on the entity itself.
     * In practice it simply returns the current instance.
     */
    public Product getProductById(int reference) {
        return this;
    }

    public void setReference(int reference) {
        this.reference = reference;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public void setPurchasePrice(double purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    public void setSellingPrice(double sellingPrice) {
        this.sellingPrice = sellingPrice;
    }

    public void setStockQuantity(int stockQuantity) {
        this.stockQuantity = stockQuantity;
    }

    /**
     * Copies another product's values into this instance.
     */
    public void setProduct(Product product) {
        this.reference = product.getReference();
        this.designation = product.getDesignation();
        this.purchasePrice = product.getPurchasePrice();
        this.sellingPrice = product.getSellingPrice();
        this.stockQuantity = product.getStockQuantity();
    }

    @Override
    public String toString() {
        return "Product [reference=" + reference + ", designation=" + designation + ", purchasePrice=" + purchasePrice
                + ", sellingPrice=" + sellingPrice
                + ", stockQuantity=" + stockQuantity + "]";
    }
}
