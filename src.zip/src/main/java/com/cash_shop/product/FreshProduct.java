package com.cash_shop.product;
/**
 * Domain model representing fresh product in the Cash Shop system. It stores the data used by the application and exposes it through simple accessors.
 *
 * This class is part of the Cash Shop desktop application.
 * It keeps the data model, business logic, persistence layer, and UI concerns separated
 * so the project remains easier to understand and share with other developers.
 */




public class FreshProduct extends Product {

    private String expirationDate;
    private double storageTemperature;

    public FreshProduct(int reference, String designation, double purchasePrice, double sellingPrice, int stockQuantity, String expirationDate, 
        double storageTemperature) {
        super(reference, designation, purchasePrice, sellingPrice, stockQuantity);
        this.expirationDate = expirationDate;
        this.storageTemperature = storageTemperature;
    }

    // Getter and Setter for expirationDate

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    // Getter and Setter for storageTemperature

    public double getStorageTemperature() {
        return storageTemperature;
    }

    public void setStorageTemperature(double storageTemperature) {
        this.storageTemperature = storageTemperature;
    }

}
