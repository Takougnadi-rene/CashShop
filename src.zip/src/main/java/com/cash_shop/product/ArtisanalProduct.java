package com.cash_shop.product;

import java.util.Locale;
/**
 * Domain model representing artisanal product in the Cash Shop system. It stores the data used by the application and exposes it through simple accessors.
 *
 * This class is part of the Cash Shop desktop application.
 * It keeps the data model, business logic, persistence layer, and UI concerns separated
 * so the project remains easier to understand and share with other developers.
 */



public class ArtisanalProduct extends Product {
/**
 * Classe principale du module type artisanal dans l'application Cash Shop. Elle regroupe les responsabilit?s de ce composant pour garder le code lisible et plus facile ? maintenir.
 *
 * Cette classe fait partie de l'application de gestion de supermarch?.
 * Elle aide ? s?parer la logique m?tier, l'acc?s aux donn?es et l'interface
 * utilisateur pour garder le projet plus clair et plus facile ? partager.
 */
/**
 * Core class for the type artisanal feature. It groups responsibilities for this component so the code stays readable and easier to maintain.
 *
 * This class is part of the Cash Shop desktop application.
 * It keeps the data model, business logic, persistence layer, and UI concerns separated
 * so the project remains easier to understand and share with other developers.
 */


public enum TypeArtisanal {
        BAKERY, FISHMONGER, BUTCHER;

        public static TypeArtisanal from(String type) {
            String normalized = type.trim().toUpperCase(Locale.ROOT);
            if ("BACERY".equals(normalized)) {
                normalized = "BAKERY";
            }
            return valueOf(normalized);
        }
    }

    private TypeArtisanal artisanalType;

    public ArtisanalProduct(int reference, String designation, double purchasePrice, double sellingPrice,
            int stockQuantity,
            TypeArtisanal type) {
        super(reference, designation, purchasePrice, sellingPrice, stockQuantity);
        this.artisanalType = type;
    }
    // getters and setters

    public String getType() {
        return artisanalType.name();
    }

    public void setType(String type) {
        if (type == null || type.trim().isEmpty()) {
            artisanalType = null;
            return;
        }
        artisanalType = TypeArtisanal.from(type);
    }

    public TypeArtisanal getArtisanalType() {
        return artisanalType;
    }

    @Override
    public String toString() {
        return "ArtisanalProduct [reference=" + getReference() + ", designation=" + getDesignation()
                + ", purchasePrice=" + getPurchasePrice() + ", sellingPrice=" + getSellingPrice()
                + ", stockQuantity=" + getStockQuantity() + ", artisanalType=" + artisanalType + "]";
    }
}