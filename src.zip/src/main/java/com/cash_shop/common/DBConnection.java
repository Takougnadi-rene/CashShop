package com.cash_shop.common;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 * Core class for the dbconnection feature. It groups responsibilities for this component so the code stays readable and easier to maintain.
 *
 * This class is part of the Cash Shop desktop application.
 * It keeps the data model, business logic, persistence layer, and UI concerns separated
 * so the project remains easier to understand and share with other developers.
 */



public class DBConnection {

    // Alternative connection URLs kept for local or remote environment testing.
    //private static final String URL = "jdbc:mysql://vmnar-102-22-134-50.run.pinggy-free.link:37509/cash_shop";
    //private static final String URL = "jdbc:mysql://localhost:3306/cash_shop";

    // The application currently connects to the local network database.
    private static final String URL = "jdbc:mysql://192.168.1.102:3306/cash_shop";
    private static final String USER = "linux";
    private static final String PASSWORD = "kingbrain@2.0";

    /**
     * Opens and returns a live JDBC connection to the configured database.
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}