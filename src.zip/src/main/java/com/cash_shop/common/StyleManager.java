package com.cash_shop.common;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.UIManager;
import javax.swing.border.AbstractBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
/**
 * Core class for the style manager feature. It groups responsibilities for this component so the code stays readable and easier to maintain.
 *
 * This class is part of the Cash Shop desktop application.
 * It keeps the data model, business logic, persistence layer, and UI concerns separated
 * so the project remains easier to understand and share with other developers.
 */



public class StyleManager {

    // ── Palette de couleurs ──────────────────────────────────────────────────
    public static final Color BG_DEEP        = new Color(0x0F, 0x11, 0x17);  // fond principal
    public static final Color BG_SURFACE     = new Color(0x16, 0x18, 0x22);  // fond carte
    public static final Color BG_CARD        = new Color(0x1E, 0x21, 0x30);  // fond panneau
    public static final Color BG_INPUT       = new Color(0x25, 0x28, 0x3A);  // fond champ
    public static final Color ACCENT_PRIMARY = new Color(0x6C, 0x63, 0xFF);  // violet
    public static final Color ACCENT_TEAL    = new Color(0x00, 0xD4, 0xAA);  // teal
    public static final Color ACCENT_ORANGE  = new Color(0xFF, 0x8C, 0x42);  // orange
    public static final Color TEXT_PRIMARY   = new Color(0xF0, 0xF2, 0xFF);  // blanc doux
    public static final Color TEXT_SECONDARY = new Color(0x8A, 0x8F, 0xB5);  // gris bleuté
    public static final Color BORDER_COLOR   = new Color(0x2E, 0x32, 0x4A);  // bordure subtile

    // ── Couleurs sémantiques ─────────────────────────────────────────────────
    public static final Color SUCCESS = new Color(0x00, 0xD4, 0xAA);
    public static final Color WARNING = new Color(0xFF, 0xB8, 0x00);
    public static final Color DANGER  = new Color(0xFF, 0x4D, 0x6D);

    // ── Polices ──────────────────────────────────────────────────────────────
    private static final Font FONT_TITLE    = new Font("Segoe UI", Font.BOLD, 20);
    private static final Font FONT_SUBTITLE = new Font("Segoe UI", Font.BOLD, 14);
    private static final Font FONT_BODY     = new Font("Segoe UI", Font.PLAIN, 13);
    private static final Font FONT_BUTTON   = new Font("Segoe UI", Font.BOLD, 12);
    private static final Font FONT_INPUT    = new Font("Segoe UI", Font.PLAIN, 13);

    // ─────────────────────────────────────────────────────────────────────────
    // Initialisation globale
    // ─────────────────────────────────────────────────────────────────────────
/**
 * Classe principale du module gradient panel dans l'application Cash Shop. Elle regroupe les responsabilit?s de ce composant pour garder le code lisible et plus facile ? maintenir.
 *
 * Cette classe fait partie de l'application de gestion de supermarch?.
 * Elle aide ? s?parer la logique m?tier, l'acc?s aux donn?es et l'interface
 * utilisateur pour garder le projet plus clair et plus facile ? partager.
 */
/**
 * Core class for the gradient panel feature. It groups responsibilities for this component so the code stays readable and easier to maintain.
 *
 * This class is part of the Cash Shop desktop application.
 * It keeps the data model, business logic, persistence layer, and UI concerns separated
 * so the project remains easier to understand and share with other developers.
 */


public static class GradientPanel extends JPanel {
        private final Color color1;
        private final Color color2;

        public GradientPanel(Color c1, Color c2) {
            this.color1 = c1;
            this.color2 = c2;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setPaint(new GradientPaint(0, 0, color1, getWidth(), getHeight(), color2));
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.dispose();
            super.paintComponent(g);
        }
    }
}

