package com.cash_shop.payment;
/**
 * Service layer for the payment service workflow. It centralizes validation, business rules, and orchestration logic for this module.
 *
 * This class is part of the Cash Shop desktop application.
 * It keeps the data model, business logic, persistence layer, and UI concerns separated
 * so the project remains easier to understand and share with other developers.
 */




public class PaymentService {

    public boolean processPayment(Payment payment) {
        if (validatePayment(payment)) {
            PaymentDAO paymentDAO = new PaymentDAO();
            paymentDAO.insertPayment(payment);
            return true;
        } else {
            return false;
        }
    }

    public boolean validatePayment(Payment payment) {
        return payment.getAmount() > 0 && payment.getPaymentDate() != null && payment.getPaymentMode() != null
                && payment.getSale() != null;
    }

    public void displayPaymentDetails(Payment payment) {
        System.out.println("Payment Details:");
        System.out.println("Payment Number: " + payment.getPaymentNumber());
        System.out.println("Amount: " + payment.getAmount());
        System.out.println("Payment Mode: " + payment.getPaymentMode());
        System.out.println("Payment Date: " + payment.getPaymentDate());
        System.out.println("Sale ID: " + payment.getSale().getSaleId());
    }
}
