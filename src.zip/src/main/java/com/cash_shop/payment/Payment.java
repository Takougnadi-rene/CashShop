package com.cash_shop.payment;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

import com.cash_shop.sale.Sale;
/**
 * Domain model representing payment in the Cash Shop system. It stores the data used by the application and exposes it through simple accessors.
 *
 * This class is part of the Cash Shop desktop application.
 * It keeps the data model, business logic, persistence layer, and UI concerns separated
 * so the project remains easier to understand and share with other developers.
 */



public class Payment {
    private int paymentNumber;
    private double amount;
    private Date paymentDate;
    private Sale sale;
    private String paymentMode;
/**
 * Classe principale du module payment mode dans l'application Cash Shop. Elle regroupe les responsabilit?s de ce composant pour garder le code lisible et plus facile ? maintenir.
 *
 * Cette classe fait partie de l'application de gestion de supermarch?.
 * Elle aide ? s?parer la logique m?tier, l'acc?s aux donn?es et l'interface
 * utilisateur pour garder le projet plus clair et plus facile ? partager.
 */
/**
 * Core class for the payment mode feature. It groups responsibilities for this component so the code stays readable and easier to maintain.
 *
 * This class is part of the Cash Shop desktop application.
 * It keeps the data model, business logic, persistence layer, and UI concerns separated
 * so the project remains easier to understand and share with other developers.
 */


public enum PaymentMode {
        CASH,
        CREDIT_CARD,
        MOBILE_PAYMENT
    }

    public Payment(int paymentNumber, double amount, LocalDateTime paymentDate, Sale sale, PaymentMode paymentMode) {
        this.paymentNumber = paymentNumber;
        this.amount = amount;
        this.paymentDate = paymentDate == null ? null : java.sql.Timestamp.valueOf(paymentDate);
        this.sale = sale;
        this.paymentMode = paymentMode.name();
    }

    public Payment(int paymentNumber, double amount, LocalDate paymentDate, Sale sale, PaymentMode paymentMode) {
        this(paymentNumber, amount, paymentDate == null ? null : paymentDate.atStartOfDay(), sale, paymentMode);
    }

    public int getPaymentNumber() {return paymentNumber;}
    public void setPaymentNumber(int paymentNumber) {this.paymentNumber = paymentNumber;}
    public double getAmount() {return amount;}
    public void setAmount(double amount) {this.amount = amount;}
    public PaymentMode getPaymentMode() {return PaymentMode.valueOf(this.paymentMode);}
    public void setPaymentMode(PaymentMode paymentMode) {this.paymentMode = paymentMode.name();}
    public Date getPaymentDate() {return paymentDate;}
    public void setPaymentDate(Date paymentDate) {this.paymentDate = paymentDate;}
    public Sale getSale() {return sale;}
    public void setSale(Sale sale) {this.sale = sale;}
}
