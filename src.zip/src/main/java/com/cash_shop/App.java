package com.cash_shop;

import com.cash_shop.common.StyleManager;
import com.cash_shop.user.UserView;
/**
 * Core class for the app feature. It groups responsibilities for this component so the code stays readable and easier to maintain.
 *
 * This class is part of the Cash Shop desktop application.
 * It keeps the data model, business logic, persistence layer, and UI concerns separated
 * so the project remains easier to understand and share with other developers.
 */




public class App {
    public static void main(String[] args) {
        // Apply the custom UI styling before creating the main window.
        StyleManager.applyLookAndFeel();

        // Start the Swing UI on the Event Dispatch Thread (EDT).
        javax.swing.SwingUtilities.invokeLater(() -> {
            UserView userView = new UserView();
            userView.setVisible(true);
        });
    }
}
