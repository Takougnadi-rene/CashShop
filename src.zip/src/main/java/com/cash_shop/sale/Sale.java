package com.cash_shop.sale;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;

import com.cash_shop.employee.Employee;
import com.cash_shop.product.Product;
/**
 * Domain model representing sale in the Cash Shop system. It stores the data used by the application and exposes it through simple accessors.
 *
 * This class is part of the Cash Shop desktop application.
 * It keeps the data model, business logic, persistence layer, and UI concerns separated
 * so the project remains easier to understand and share with other developers.
 */




public class Sale {
    private int saleId;
    private LocalDateTime saleDate;
    private Employee cashier;
    private ArrayList<Product> productsList;

    public Sale(int saleId, LocalDateTime saleDate, Employee cashier) {
        this.saleId = saleId;
        this.saleDate = saleDate;
        this.cashier = cashier;
    }

    public Sale(int saleId, LocalDate saleDate, Employee cashier) {
        this(saleId, saleDate == null ? null : saleDate.atStartOfDay(), cashier);
    }

    public int getSaleId() {
        return saleId;
    }

    public void setSaleId(int saleId) {
        this.saleId = saleId;
    }

    public LocalDateTime getSaleDate() {
        return saleDate;
    }

    public void setSaleDate(LocalDateTime saleDate) {
        this.saleDate = saleDate;
    }

    public void setSaleDate(LocalDate saleDate) {
        this.saleDate = saleDate == null ? null : saleDate.atStartOfDay();
    }

    public Employee getCashier() {
        return cashier;
    }

    public void setCashier(Employee cashier) {
        this.cashier = cashier;
    }

    public ArrayList<Product> getProductsList() {
        return productsList;
    }

    public void setProductsList(ArrayList<Product> productsList) {
        this.productsList = productsList;
    }

    @Override
    public String toString() {
        return "Sale [saleId=" + saleId + ", saleDate=" + saleDate + ", cashier="
                + cashier.getFirstName() + " " + cashier.getLastName() + ", productsList="
                + productsList + "]";
    }
}
