package com.cash_shop.bill;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import com.cash_shop.customer.Customer;
import com.cash_shop.employee.Employee;
import com.cash_shop.product.Product;
import com.cash_shop.sale.Sale;
import com.cash_shop.sale.SaleService;
/**
 * Domain model representing bill in the Cash Shop system. It stores the data used by the application and exposes it through simple accessors.
 *
 * This class is part of the Cash Shop desktop application.
 * It keeps the data model, business logic, persistence layer, and UI concerns separated
 * so the project remains easier to understand and share with other developers.
 */




public class Bill {
    private int billNumber;
    private Date billDate;
    private Customer customer;
    private Employee cashier;
    private Sale sale;

    public Bill(int billNumber, Date billDate, Customer customer, Employee cashier, Sale sale) {
        this.billNumber = billNumber;
        this.billDate = billDate;
        this.customer = customer;
        this.cashier = cashier;
        this.sale = sale;
    }

    public int getBillNumber() {return billNumber;}
    public Date getBillDate() {return billDate;}
    public Customer getCustomer() {return customer;}
    public Employee getCashier() {return cashier;}
    public Sale getSale() {return sale;}

    //bill generator method
    public String genererFacture() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        StringBuilder sb = new StringBuilder();
        double total = new SaleService().calculateTotal(sale);


        sb.append("================================================
");
        sb.append("        SUPER MARKET PLUS
");
        sb.append("         Purchase Receipt
");
        sb.append("================================================

");
        sb.append(String.format("Receipt No.: %04d        Date: %s
", billNumber, sdf.format(billDate)));
        sb.append(String.format("Cashier    : %-15s Customer: %s
",
                cashier != null ? cashier.getFirstName() + " " + cashier.getLastName() : "N/A",
                customer != null ? customer.getName() : "Walk-in"));
        sb.append("
------------------------------------------------
");
        sb.append(String.format("%-20s %5s %15s
", "PRODUCT", "QTY", "PRICE ($)"));
        sb.append("------------------------------------------------
");

        Map<Integer, Product> productsByReference = new LinkedHashMap<>();
        Map<Integer, Integer> quantitiesByReference = new LinkedHashMap<>();
        for (Product product : sale.getProductsList()) {
            productsByReference.putIfAbsent(product.getReference(), product);
            quantitiesByReference.merge(product.getReference(), 1, Integer::sum);
        }
        for (Map.Entry<Integer, Product> entry : productsByReference.entrySet()) {
            Product product = entry.getValue();
            sb.append(String.format("%-20s %5d %15.0f $
",
                    product.getDesignation(), quantitiesByReference.get(entry.getKey()), product.getSellingPrice()));
        }

        sb.append("
------------------------------------------------
");
        sb.append(String.format("TOTAL DUE:               %15.0f $
", total));
        sb.append("
================================================
");
        sb.append("         Thank you for shopping with us!
");
        sb.append("         See you again soon.
");
        sb.append("================================================
");
        return sb.toString();
    }
}
