package com.cash_shop.bill;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cash_shop.common.DBConnection;
/**
 * Data access object for the bill dao layer. It encapsulates database queries and persistence logic so the rest of the application remains clean and easier to maintain.
 *
 * This class is part of the Cash Shop desktop application.
 * It keeps the data model, business logic, persistence layer, and UI concerns separated
 * so the project remains easier to understand and share with other developers.
 */




public class BillDAO {

    public void addBill(Bill bill) {
        String sql = "INSERT INTO bills(bill_number, bill_date, customer, cashier) VALUES (?, ?, ?, ?)";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, bill.getBillNumber());
            ps.setTimestamp(2, new java.sql.Timestamp(bill.getBillDate().getTime()));
            ps.setInt(3, bill.getCustomer().getCustomerId());
            ps.setString(4, bill.getCashier().getMatricule());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Bill getBill(int billNumber) {
        String sql = "SELECT bill_number, bill_date FROM bills WHERE bill_number = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, billNumber);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Bill(
                        rs.getInt("bill_number"),
                        rs.getTimestamp("bill_date"),
                        null,  // customer: extend query if needed
                        null,  // cashier: extend query if needed
                        null   // sale: extend query if needed
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}

